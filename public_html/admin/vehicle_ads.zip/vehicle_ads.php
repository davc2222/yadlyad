<?php
require_once '../includes/db.php';
require_once '../includes/admin_header.php';
require_once '../includes/admin_sidebar.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function statusText($status) {
    if ($status === 'approved') return 'מאושרת';
    if ($status === 'rejected') return 'נדחתה';
    return 'ממתינה לאישור';
}

function statusClass($status) {
    if ($status === 'approved') return 'approved';
    if ($status === 'rejected') return 'rejected';
    return 'pending';
}

$action = $_GET['action'] ?? '';
$id = (int)($_GET['id'] ?? 0);

if ($id > 0 && in_array($action, ['approve', 'reject', 'delete'], true)) {

    if ($action === 'approve') {
        $stmt = $pdo->prepare("UPDATE vehicle_ads SET status = 'approved' WHERE id = ?");
        $stmt->execute([$id]);
    }

    if ($action === 'reject') {
        $stmt = $pdo->prepare("UPDATE vehicle_ads SET status = 'rejected' WHERE id = ?");
        $stmt->execute([$id]);
    }

    if ($action === 'delete') {
        $stmt = $pdo->prepare("UPDATE vehicle_ads SET is_deleted = 1 WHERE id = ?");
        $stmt->execute([$id]);
    }

    header('Location: /admin/vehicle_ads.php');
    exit;
}

$status = $_GET['status'] ?? 'all';
$q = trim($_GET['q'] ?? '');

$where = ["va.is_deleted = 0"];
$params = [];

if (in_array($status, ['pending', 'approved', 'rejected'], true)) {
    $where[] = "va.status = ?";
    $params[] = $status;
}

if ($q !== '') {
    $where[] = "(
        va.title LIKE ?
        OR cm.name LIKE ?
        OR cmo.name LIKE ?
        OR u.name LIKE ?
        OR u.email LIKE ?
        OR u.phone LIKE ?
        OR va.phone LIKE ?
        OR CAST(va.id AS CHAR) LIKE ?
    )";

    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, $like, $like, $like, $like, $like);
}

$whereSql = implode(' AND ', $where);

$countStmt = $pdo->query("
    SELECT
        COUNT(*) AS total,
        SUM(status = 'pending') AS pending,
        SUM(status = 'approved') AS approved,
        SUM(status = 'rejected') AS rejected
    FROM vehicle_ads
    WHERE is_deleted = 0
");
$counts = $countStmt->fetch(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("
    SELECT
        va.id,
        va.title,
        va.description,
        va.price,
        va.phone AS ad_phone,
        va.status,
        va.created_at,
        va.year,
        va.hand,
        va.km,
        cm.name AS maker_name,
        cmo.name AS model_name,
        u.name AS user_name,
        u.email AS user_email,
        u.phone AS user_phone,
        img.image_path
    FROM vehicle_ads va
    LEFT JOIN car_makers cm ON cm.id = va.manufacturer_id
    LEFT JOIN car_models cmo ON cmo.id = va.model_id
    LEFT JOIN users u ON u.id = va.user_id
    LEFT JOIN vehicle_images img
        ON img.ad_id = va.id
       AND img.id = (
            SELECT img2.id
            FROM vehicle_images img2
            WHERE img2.ad_id = va.id
            ORDER BY img2.is_main DESC, img2.sort_order ASC, img2.id ASC
            LIMIT 1
       )
    WHERE $whereSql
    ORDER BY
        CASE va.status
            WHEN 'pending' THEN 1
            WHEN 'approved' THEN 2
            WHEN 'rejected' THEN 3
            ELSE 4
        END,
        va.created_at DESC,
        va.id DESC
");
$stmt->execute($params);
$ads = $stmt->fetchAll(PDO::FETCH_ASSOC);


function activeTab($current, $value) {
    return $current === $value ? ' active' : '';
}
?>

<style>

.admin-vehicles-page{
    direction:rtl;
    max-width:1150px;
    margin:0 auto;
}

.vehicle-admin-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:20px;
    margin-bottom:20px;
}

.vehicle-admin-header h1{
    margin:0;
    font-size:30px;
    font-weight:900;
    color:#111827;
}

.vehicle-admin-header p{
    margin:5px 0 0;
    color:#6b7280;
}

.new-ad-btn{
    background:#2563eb;
    color:#fff;
    text-decoration:none;
    padding:11px 16px;
    border-radius:10px;
    font-weight:800;
}

.stats-row{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:12px;
    margin-bottom:18px;
}

.stat-card{
    background:#fff;
    border:1px solid #e5e7eb;
    border-radius:12px;
    padding:14px;
    text-decoration:none;
    color:#111827;
    text-align:center;
}

.stat-card.active{
    border-color:#2563eb;
    box-shadow:0 0 0 2px rgba(37,99,235,.15);
}

.stat-card strong{
    display:block;
    margin-bottom:6px;
}

.stat-card span{
    font-size:22px;
    font-weight:900;
}

.search-box{
    background:#fff;
    border:1px solid #e5e7eb;
    border-radius:12px;
    padding:12px;
    display:flex;
    gap:10px;
    margin-bottom:20px;
}

.search-box input{
    flex:1;
    height:42px;
    border:1px solid #d1d5db;
    border-radius:8px;
    padding:0 12px;
}

.search-box button{
    border:0;
    background:#2563eb;
    color:#fff;
    padding:0 20px;
    border-radius:8px;
    font-weight:800;
    cursor:pointer;
}

.vehicle-card{
    display:flex;
    gap:18px;
    background:#fff;
    border:1px solid #e5e7eb;
    border-radius:14px;
    margin-bottom:18px;
    overflow:hidden;
    box-shadow:0 2px 8px rgba(0,0,0,.05);
}

.vehicle-image{
    width:250px;
    min-width:250px;
    background:#f3f4f6;
}

.vehicle-image img{
    width:100%;
    height:100%;
    min-height:180px;
    object-fit:cover;
    display:block;
}

.no-image{
    height:180px;
    display:flex;
    justify-content:center;
    align-items:center;
    color:#9ca3af;
    font-weight:800;
}

.vehicle-body{
    flex:1;
    padding:18px;
}

.vehicle-head{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:15px;
}

.vehicle-head h2{
    margin:0;
    font-size:23px;
    font-weight:900;
}

.vehicle-price{
    font-size:24px;
    font-weight:900;
    color:#2563eb;
}

.status{
    display:inline-block;
    margin-top:8px;
    padding:5px 12px;
    border-radius:999px;
    font-size:12px;
    font-weight:900;
}

.status.pending{
    background:#fff3cd;
    color:#8a6d00;
}

.status.approved{
    background:#d1fae5;
    color:#065f46;
}

.status.rejected{
    background:#fee2e2;
    color:#991b1b;
}

.vehicle-info{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:10px;
    margin-top:18px;
}

.info-box{
    background:#f9fafb;
    border:1px solid #e5e7eb;
    border-radius:10px;
    padding:10px;
}

.info-box span{
    display:block;
    color:#6b7280;
    font-size:12px;
    margin-bottom:4px;
}

.info-box strong{
    font-size:14px;
}

.vehicle-desc{
    margin-top:18px;
    color:#374151;
    line-height:1.7;
}

.vehicle-actions{
    display:flex;
    gap:8px;
    flex-wrap:wrap;
    margin-top:20px;
}

.vehicle-actions a{
    text-decoration:none;
    padding:9px 14px;
    border-radius:9px;
    font-weight:800;
    font-size:14px;
}

.btn-manage{
    background:#e5e7eb;
    color:#111827;
}

.btn-edit{
    background:#dbeafe;
    color:#1d4ed8;
}

.btn-approve{
    background:#16a34a;
    color:white;
}

.btn-reject{
    background:#dc2626;
    color:white;
}

.btn-delete{
    background:#111827;
    color:white;
}

.empty-box{
    background:#fff;
    border:1px solid #e5e7eb;
    border-radius:12px;
    padding:35px;
    text-align:center;
    color:#6b7280;
}

@media(max-width:900px){

.vehicle-card{
    flex-direction:column;
}

.vehicle-image{
    width:100%;
    min-width:100%;
}

.vehicle-info{
    grid-template-columns:repeat(2,1fr);
}

.stats-row{
    grid-template-columns:repeat(2,1fr);
}

.search-box{
    flex-direction:column;
}

}
</style>
